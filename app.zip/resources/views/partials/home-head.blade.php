
  <link rel="stylesheet" href="{{url('/')}}/resources/them/home_slider/loopslider.css">
  <link rel="stylesheet" href="{{url('/')}}/resources/them/home_slider/demo/default.css">
  <script src="{{url('/')}}/resources/them/OwlCarousel/docs/assets/vendors/jquery.min.js"></script>
  <script src="{{url('/')}}/resources/them/OwlCarousel/docs/assets/owlcarousel/owl.carousel.js"></script>
  <link rel="stylesheet" href="{{url('/')}}/resources/them/OwlCarousel/docs/assets/owlcarousel/assets/owl.carousel.min.css">
  <link rel="stylesheet" href="{{url('/')}}/resources/them/OwlCarousel/docs/assets/owlcarousel/assets/owl.theme.default.min.css">
