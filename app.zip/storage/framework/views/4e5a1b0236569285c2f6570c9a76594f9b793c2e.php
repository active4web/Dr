

  <script>
$(document).ready(function(e) {
//toastr.info("ddd",  {timeOut:1200000});
$(".send_txt").click(function(e) {
var name = $("#name").val();
var phone = $("#phone").val();
var message = $("#message").val();
var email = $("#email").val();
var form = $("#myform");
//var form=$("#myForm");
    var data=form.serialize();
//alert(data);
    if (name=="") {
			toastr.info("<?php echo e(trans('messages.required_name')); ?>",  {timeOut: 5000});
		}
    if (phone=="") {
			toastr.info("<?php echo e(trans('messages.required_phone')); ?>",  {timeOut: 5000});
        }
        if (email=="") {
			toastr.info("<?php echo e(trans('messages.required_email')); ?>",  {timeOut: 5000});
        }

    if (message=="") {
			toastr.info("<?php echo e(trans('messages.required_message')); ?>",  {timeOut: 5000});
        }
 if(name!=""&&phone!=""&&message!=""&&email!="") {
			$.ajax({
				url:"<?php echo e(url('contact_action')); ?>",
                type: 'POST',
                data: data,
                success: function( data ) {
               //alert(data);
                	if (data == "1") {
					toastr.success("<?php echo e(trans('messages.sendmessage_result_send')); ?>",  {timeOut: 5000});
                	}
                  if (data == "0") {
					toast.info("<?php echo e(trans('messages.sendmessage_result_send')); ?>",  {timeOut: 5000});
                	}
				}
         });
 }
	});
});
</script>
  <script src="<?php echo e(url('/')); ?>/resources/them/toastr/toastr.min.js""></script>

<link href="<?php echo e(url('/')); ?>/resources/them/toastr/toastr.min.css" rel="stylesheet">
<?php /**PATH C:\wamp64\www\mywork\gasc\resources\views/partials/toastr.blade.php ENDPATH**/ ?>