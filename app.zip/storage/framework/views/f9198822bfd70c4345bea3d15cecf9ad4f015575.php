</head>
<?php
foreach($sitesetting as $sitesetting)

?>

<body>
<div class="header home top abo" style="background: url(<?php echo e(url('/')); ?>/uploads/site_setting/uYYa.jpg)no-repeat center;background-size: 100% 100%;">

					<div class="overlay">
					<div class="container">
						<div class="row" style="margin-left: 0px;margin-right:0px;">
						<div class="col-md-6 col-sm-6 col-xs-12">
								<div class="sochal">
										<a href="<?php echo e($sitesetting->whatsapp); ?>" target="_blank"><i class="fab fa-whatsapp fa-lg"></i></a>
										<a href="<?php echo e($sitesetting->facebook); ?>" target="_blank"><i class="fab fa-facebook-f fa-lg"></i></a>
										<a href="<?php echo e($sitesetting->twitter); ?>"  target="_blank"><i class="fab fa-twitter fa-lg"></i></a>

									</div>

							</div>
							<div class="col-md-6 col-sm-6 col-xs-12"  style="text-align:center">

									<div class="cont">
											<li><i class="fa fa-envelope-open"></i><?php echo e($sitesetting->email); ?></li>
											<li><i class="fa fa-phone phone"></i><?php echo e($sitesetting->phone); ?></li>
										</div>

									<div class="dropdown">
											<button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
											  اللغة
											  <span class="caret"></span>
											</button>
											<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
											  <li><a href="#">عربي</a></li>
											  <li><a href="en/index.html">انجليزي</a></li>

											</ul>
										  </div>





							</div>

						</div>


                    </div>


					 <!--start navbar-->
						<nav class="navbar navbar-inverse "  role="navigation" id="nav-b">
							<div class="container">
							<!-- Brand and toggle get grouped for better mobile display -->
								<div class="navbar-header">
								   <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#axit-nav" aria-expanded="false">
									 <span class="sr-only">Toggle navigation</span>
									 <span class="icon-bar"></span>
									 <span class="icon-bar"></span>
									 <span class="icon-bar"></span>
								   </button>
									<a class="navbar-brand" href="index.html">
                        <img class="img-responsive center-block" src="<?php echo e(url('/')); ?>/uploads/site_setting/<?php echo e($sitesetting->logo); ?>"></a>
								</div>
								<div class="collapse navbar-collapse" id="axit-nav">
            <ul class="nav navbar-nav navbar-left">
                <li class="<?php echo e((request()->is('/')) ? 'active' : ''); ?>"><a href="<?php echo e(url('/')); ?>">الرئيسية</a></li>
                <li class="<?php echo e((request()->is('about')) ? 'active' : ''); ?>"><a href="<?php echo e(url('/')); ?>/about">من نحن</a></li>
                <li class="<?php echo e((request()->is('services')) ? 'active' : ''); ?>"><a href="<?php echo e(url('/')); ?>/services">الخدمات</a></li>
<li class="<?php if(Request::segment(1)=="works"||Request::segment(1)=="details"){?>active <?php }?>"><a href="<?php echo e(url('/')); ?>/works">الأعمال</a></li>
                <li class="<?php echo e((request()->is('clients')) ? 'active' : ''); ?>"><a href="<?php echo e(url('/')); ?>/clients">العملاء</a></li>
                <li class="<?php if(Request::segment(1)=="events"||strpos(Request::segment(1),"-details")==5){?>active <?php }?>">
                <a href="<?php echo e(url('/')); ?>/events">فعاليات الشركة</a></li>
                <li ><a href="#">التوظيف</a></li>
                <li class="<?php echo e((request()->is('contact')) ? 'active' : ''); ?>"><a href="<?php echo e(url('/')); ?>/contact">اتصل بنا</a></li>
            </ul>
									 </div><!-- /.navbar-collapse -->
							</div><!-- /.container-fluid -->
						 </nav>
<?php /**PATH C:\wamp64\www\mywork\laravelv1\resources\views/partials/header.blade.php ENDPATH**/ ?>