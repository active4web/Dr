<?php $__env->startSection('content'); ?>




    <!-- Preloader Begin -->
    <?php
foreach($home_page as $homepage)
foreach($site_info as $site_data)
?>

<div class="container">
<div class="col-md-1 col-sm-12 col-xs-12 "></div>
<div class="col-md-5 col-sm-12 col-xs-12 ">

<!--start carousel-->
  <div id="carousel-example-generic" class="carousel slide text-center" data-ride="carousel">
<!-- Wrapper for slides -->
	  <div class="carousel-inner" role="listbox">
	  <div class="item active home_active">
		  <h3 class="apparcase text-center-xs" style="font-size:18px;text-align:center"><?php echo $homepage->title; ?></h3>
			<p style="font-size:14px"><?php echo $homepage->breif_txt_ar; ?></p>
			<a class="more" href="">اكتشف المزيد</a>
		</div>
	  </div>
	</div>
	<!--end of carousel-->
	</div>

	<div class="col-md-1 col-sm-12 col-xs-12 "></div>
	<div class="col-md-4 col-sm-12 col-xs-12 ">
	<div class="head-ser">
			<h3 style="color:#226085;font-weight: 600;font-size: 20px;margin-top:2px;margin-bottom:2px;">تواصل معانا الان</h3>
			<p style="margin: 0 0 0px">نحن نقدم العديد من الخدمات الذى يساعدك<br class="hidden-sm">فى نجاح شركتك</p>
				<div class="row">
				<form class="col-md-12" id="myform">

				<input type="hidden" name="mass_type" value="1">
							<div class="col-md-12">
								<input class="form-control input-lg" id="name" name="title" type="text" placeholder="الاسم">

							</div>
							<div class="col-md-12">
									<input class="form-control input-lg" id="phone" name="phone" type="text" placeholder="رقم الجوال">

							</div>
							<div class="col-md-12">
								<textarea class="form-control input-lg" id="message" name="message" placeholder="الرسالة"></textarea>
							</div>
							<div class="col-md-12">
									<button class="contact-btn send_txt" type="button">أرسل الآن</button>
								</div>
</form>
				</div>
</div>
</div>
<div class="col-md-1 col-sm-12 col-xs-12 "></div>
	</div>
</div>
</div>
</div></div>
<div class="clearfix"></div>
<div class="clearfix"></div>
<div class="clearfix"></div>
<div class="wrapper"  style="margin-top:30px;padding-bottom:3%">
<div class="container">
    <div class="col-md-6 col-sm-6 col-xs-12 hidden-xs">
        <div class="pic">
        <img class="img-responsive" src="<?php echo e(url('/')); ?>/uploads/site_setting/<?php echo e($homepage->team_img); ?>">
            <div class="bg-pic">
            </div>
        </div>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12 hidden-md hidden-lg hidden-sm pic1 text-center">
            <div class="pic">
        <img class="img-responsive" src="<?php echo e(url('/')); ?>/uploads/site_setting/<?php echo e($homepage->team_img); ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12 about_margin" >
        <h3 class="hed_about" >من نحن
<p class="bordbott"></p>
        </h3>
        <div class="about_p">
        <p class="about_p">{<?php echo $homepage->team_title_ar; ?>}</p>
        <a class="more" href="" style="background-color: #226085;border:0px">
            اقرا المزيد  <i class="fas fa-arrow-left"></i></a>
    </div>
    </div>
</div>
<div class="clearfix"></div>
</div>
<div class="wrapper"  style="margin-top:30px">
<div class="container">
        <div class="row">
    <div class="col-md-6 col-sm-6 col-xs-12 hidden-xs" style="background:#fff;padding-left:30px;">
        <div class="row" style="margin-left:0px;margin-right:0px;">
            <div class="col-md-12 vision_about">
                <div class="col-md-12"><img src="<?php echo e(url('/')); ?>/uploads/site_setting/Our-vision.png" style="width:50px;"></div>
                <div class="col-md-12">	<h3 class="title_vision" >رؤيتنا</h3></div>
            <div class="col-md-12"><p class="description_vision">
            <?php echo $site_data->vision; ?>

                </p></div>
            </div>
        </div>
    </div>







    <div class="col-md-6 col-sm-6 col-xs-12 hidden-xs" style="background:#fff;padding-right:30px;">
            <div class="row" style="margin-left:0px;margin-right:0px;">
                <div class="col-md-12 vision_about">
                    <div class="col-md-12"><img src="<?php echo e(url('/')); ?>/uploads/site_setting/Our-Mission.png" style="width:50px"></div>
                    <div class="col-md-12">	<h3 class="title_mission" >رسالتنا</h3></div>
                <div class="col-md-12"><p class="description_mission"><?php echo $site_data->mission; ?>

                    </p></div>
                </div>
            </div>
        </div>





</div>
</div>
<div class="clearfix"></div>
</div>
<div class="wrapper"  style="margin-top:30px;padding-bottom:3%">
						<div class="container" style="direction: ltr">
								<div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
							<h3 class="hed_about" >خدماتنا <p class="bordbott" style="margin-left:auto;margin-right:auto"></p></h3>
							</div>


							<div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
								<section class="services slider">
<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_services): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="our_services">
                    <img src="<?php echo e(url('/')); ?>/uploads/services/<?php echo e($data_services->img); ?>">
                    <h3 class="servivce_title" ><?php echo e($data_services->title); ?><p class="bordbott"></p></h3>
                    <div class="about_p" style="padding-right:0px">
                    <p class="servivce_description"><?php echo e($data_services->description_ar); ?>

                    </p></div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




									  </section>



					</div>
<?php echo $__env->make("partials.clients", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

					</div>

                </div>


<?php $__env->stopSection(); ?>
</div></div>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\mywork\laravelv1\resources\views/pages/home.blade.php ENDPATH**/ ?>