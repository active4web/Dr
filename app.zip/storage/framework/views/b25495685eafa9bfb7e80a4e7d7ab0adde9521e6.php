

<?php
foreach($sitesetting as $sitesetting)

?>
  <title>مدى</title>
  <meta charset="UTF-8">

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/them/slick/slick.css">
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/them/slick/slick-theme.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

  <link href="<?php echo e(url('/')); ?>/resources/them/css/bootstrap.css" rel="stylesheet" type="text/css">
  <link href="<?php echo e(url('/')); ?>/resources/them/css/style.css" rel="stylesheet" type="text/css">
  <link href="<?php echo e(url('/')); ?>/resources/them/css/customs.css" rel="stylesheet" type="text/css">
  <link href="<?php echo e(url('/')); ?>/resources/them/css/main.css" rel="stylesheet" type="text/css">
  <style>
		@import  url(http://fonts.googleapis.com/earlyaccess/notosanskufiarabic.css);
		</style>
	<link rel="shortcut icon" href="https://tasks.wisyst.info/uploads/site_setting/icon.png" type="image/x-icon" />

<?php /**PATH C:\wamp64\www\mywork\laravelv1\resources\views/partials/head.blade.php ENDPATH**/ ?>