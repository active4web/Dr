</head>
<?php
foreach($site_info as $sitesetting)

?>
<body >
<div style="overflow-x: hidden;">
				<div class="header home ">
					<div class="overlay-home ">
					<div style="border-bottom:1px solid #cccccc4a;">
							<div class="container">
									<div class="row" style="margin-left: 0px;margin-right:0px;">
									<div class="col-md-6 col-sm-6 col-xs-12">
										<div class="dropdown">
											<button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                            <?php echo e(trans('messages.lang')); ?>

											  <span class="caret"></span>
											</button>
											<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
											  <li><a href="<?php echo e(url('locale/ar')); ?>"><?php echo e(trans('messages.ar_lang')); ?></a></li>
											  <li><a href="<?php echo e(url('locale/en')); ?>"><?php echo e(trans('messages.en_lang')); ?></a></li>
											</ul>
										  </div>

											<div class="sochal">
													<a href=""><i class="fab fa-instagram fa-lg inst"></i></a>
													<a href=""><i class="fab fa-twitter fa-lg"></i></a>
													<a href=""><i class="fab fa-facebook-f fa-lg"></i></a>
												</div>
										</div>
										<div class="col-md-6 col-sm-6 col-xs-12"  style="text-align:center">
										<div class="cont">
														<li><i class="fa fa-envelope"></i><?php echo e($sitesetting->email); ?></li>
														<li class="top_header_link">|</li>
														<li><i class="fas fa-phone-alt"></i><?php echo e($sitesetting->phone); ?></li>
													</div>
										</div>
									</div>
								</div>
					</div>



					 <!--start navbar-->

						<nav class="navbar navbar-inverse "  role="navigation" id="nav-b">
							<div class="container">
							<!-- Brand and toggle get grouped for better mobile display -->
								<div class="navbar-header">
								   <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#axit-nav" aria-expanded="false">
									 <span class="sr-only">Toggle navigation</span>
									 <span class="icon-bar"></span>
									 <span class="icon-bar"></span>
									 <span class="icon-bar"></span>
								   </button>
									<a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img class="img-responsive center-block" 
                                    src="<?php echo e(url('/')); ?>/backend/uploads/site_setting/<?php if(app()->getLocale() == 'ar'): ?><?php echo $sitesetting->logo; ?> <?php else: ?><?php echo $sitesetting->logo_en; ?><?php endif; ?>">
                                    
                                    </a>
								</div>

								<div class="collapse navbar-collapse" id="axit-nav">
										<ul class="nav navbar-nav navbar-left">
										 <li class="active"><a href="<?php echo e(url('/')); ?>"><?php echo e(trans('messages.home_page')); ?></a></li>
										 <li><a href="<?php echo e(url('/')); ?>/about"><?php echo e(trans('messages.about_page')); ?></a></li>
										 <li><a href="<?php echo e(url('/')); ?>/services"><?php echo e(trans('messages.service_page')); ?></a></li>
										 <li><a href="<?php echo e(url('/')); ?>/works"><?php echo e(trans('messages.works_page')); ?></a></li>
										 <li><a href="<?php echo e(url('/')); ?>/news"><?php echo e(trans('messages.news_page')); ?></a></li>
										 <li><a href="<?php echo e(url('/')); ?>/contact"><?php echo e(trans('messages.contact_page')); ?></a></li>
										</ul>

									 </div><!-- /.navbar-collapse -->

							</div><!-- /.container-fluid -->

						 </nav>
					</div>
					</div>
<?php /**PATH C:\wamp64\www\mywork\gasc\resources\views/partials/header.blade.php ENDPATH**/ ?>