
  <link rel="stylesheet" href="<?php echo e(url('/')); ?>/resources/them/home_slider/loopslider.css">
  <link rel="stylesheet" href="<?php echo e(url('/')); ?>/resources/them/home_slider/demo/default.css">
  <script src="<?php echo e(url('/')); ?>/resources/them/OwlCarousel/docs/assets/vendors/jquery.min.js"></script>
  <script src="<?php echo e(url('/')); ?>/resources/them/OwlCarousel/docs/assets/owlcarousel/owl.carousel.js"></script>
  <link rel="stylesheet" href="<?php echo e(url('/')); ?>/resources/them/OwlCarousel/docs/assets/owlcarousel/assets/owl.carousel.min.css">
  <link rel="stylesheet" href="<?php echo e(url('/')); ?>/resources/them/OwlCarousel/docs/assets/owlcarousel/assets/owl.theme.default.min.css">
<?php /**PATH /home/p2wisyst/public_html/gasc/resources/views/partials/home-head.blade.php ENDPATH**/ ?>