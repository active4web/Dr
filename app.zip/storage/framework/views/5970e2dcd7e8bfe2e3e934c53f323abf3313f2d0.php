
<link href="resources/them/css/effects.min.css" rel="stylesheet" type="text/css">
<?php /**PATH C:\wamp64\www\mywork\laravelv1\resources\views/partials/sub_head.blade.php ENDPATH**/ ?>