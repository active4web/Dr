<?php $__env->startSection('content'); ?>



<?php
//print_r($data_main);
//echo $datamain->title;
?>

<div class="container main_breadcrumb">
				<div class="row">
					<div class="col-md-12"  style="text-align: center">
						<div class="title">
							<h3><?php echo e($data_main->title); ?></h3>
						</div>
					</div>
					<div class="col-md-12" style="text-align: center;margin-top:10px;">
						<ol class="breadcrumb text-center">
							<li><a href="index.html">الرئيسية</a></li>
							<li class="active"><a href="#">فعاليات الشركة</a></li>
						</ol>
					</div>
                </div>
            </div>
            <div class="clearfix"></div>

</div>
</div></div>


<div class="wrapper" style="margin-top:30px;padding-bottom:3%">
<div class="container">
		<div class="row">
			<!--------------------------Start Row1--------------->
	<div class="col-md-5 col-sm-5 col-xs-12 hidden-xs img_work">
	<img alt="اسم العمل" class="img-thumbnail" src="<?php echo e(url('')); ?>/uploads/works/<?php echo e($data_main->img); ?>">
	</div>
	<div class="col-md-6 col-sm-6 col-xs-12 hidden-md hidden-lg hidden-sm pic1 text-center img_work">
		<img alt="اسم العمل" class="img-thumbnail" src="<?php echo e(url('')); ?>/uploads/works/<?php echo e($data_main->img); ?>">
	</div>
<div class="col-md-7 col-sm-7 col-xs-12 ">
		<div class="about_p">
        <p class="servivce_description"><?php echo $data_main->details; ?></p>
    </div>
</div>

<div class="col-md-12" style="text-align: center">

<div class="sharethis-inline-share-buttons st-center  st-inline-share-buttons st-animated" id="st-1"><div class="st-btn st-first" data-network="facebook" style="display: inline-block;">
  <img src="https://platform-cdn.sharethis.com/img/facebook-white.svg">

</div><div class="st-btn" data-network="twitter" style="display: inline-block;">
  <img src="https://platform-cdn.sharethis.com/img/twitter-white.svg">

</div><div class="st-btn" data-network="pinterest" style="display: inline-block;">
  <img src="https://platform-cdn.sharethis.com/img/pinterest-white.svg">

</div><div class="st-btn" data-network="whatsapp" style="display: inline-block;">
  <img src="https://platform-cdn.sharethis.com/img/whatsapp-white.svg">

</div><div class="st-btn st-last" data-network="sharethis" style="display: inline-block;">
  <img src="https://platform-cdn.sharethis.com/img/sharethis-white.svg">

</div></div>
<!-- AddToAny END -->
		</div>




        </div>
<!---------------------------6Row-------------------------------->
</div>
<div class="clearfix"></div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\mywork\laravelv1\resources\views/pages/event-details.blade.php ENDPATH**/ ?>