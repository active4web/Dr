
				<div class="wrapper"  style="margin-top:30px;padding-bottom:3%">
<div class="container" style="direction:ltr">
    <div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
  <h3 class="hed_about" >عملاء تشرفنا بخدمتهم
      <p class="bordbott" style="margin-left:auto;margin-right:auto"></p></h3>
  </div>
  <div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
      <section class="autoplay slider main_arrow">
  <?php if(count($home_clients)>0): ?>
	<?php $__currentLoopData = $home_clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $start_clients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div>
            <a href="<?php echo e($start_clients->link); ?>" title="<?php echo e($start_clients->title_ar); ?>" target="_blank">
            <img src="<?php echo e(url('/')); ?>/uploads/clients/<?php echo e($start_clients->img); ?>" alt="<?php echo e($start_clients->title_ar); ?>">
          </a>
          </div>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>

          </section>
</div>
<div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
<a class="more" href="<?php echo e(url('/')); ?>/clients" style="background-color: #226085;border:0px;    padding: 6px 34px;">
  <span class="more_clients" ><i class="fas fa-arrow-left"></i></span><span>المزيد</span></a>
</div>
</div>
</div>
<div class="clearfix"></div>
<?php /**PATH C:\wamp64\www\mywork\laravelv1\resources\views/partials/clients.blade.php ENDPATH**/ ?>