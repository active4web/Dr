<?php
foreach($site_info as $sitesetting)

if(app()->getLocale() == 'ar'){$footimg=$sitesetting->footer_log;}
else {$footimg=$sitesetting->footer_log_en;}

?>
	<footer>
				 <div class="overlay">
					<div class="container">
					<a href="#" class="scrollTop button" style="display: block;" id="elevator_item">
						<i class="fa fa-arrow-up" style="color:#fff;"></i></a>
                         <div class="row">
							<div class="col-md-3 col-xs-12 text-right">
								<a class="" href="index.html">
									<img class="img-responsive right-block" src="<?php echo e(url('/')); ?>/backend/uploads/site_setting/<?php echo e($footimg); ?>"
                                    </a>
									<div class="sochal pull-right mt-50">
										<a href="<?php echo e($sitesetting->instagram); ?>"  target="_blank"><i class="fab fa-instagram fa-lg"></i></a>
										<a href="<?php echo e($sitesetting->twitter); ?>"    target="_blank"><i class="fab fa-twitter fa-lg"></i></a>
										<a href="<?php echo e($sitesetting->facebook); ?>"   target="_blank"><i class="fab fa-facebook-f fa-lg"></i></a>
									</div>
							</div>




							<div class="col-md-1  col-xs-12"></div>

							<div class="col-md-4  col-xs-12">
									<h4><?php echo trans('messages.important_link'); ?></h4>
										<div class="qanon">
<div class="col-md-5 col-xs-12">
<li><a href="<?php echo e(url('/')); ?>"><i class="fas fa-external-link-alt"></i><?php echo trans('messages.home_page'); ?></a></li>
<li><a href="<?php echo e(url('/')); ?>/about"><i class="fas fa-external-link-alt"></i><?php echo trans('messages.about_page'); ?></a></li>
<li><a href="<?php echo e(url('/')); ?>/services"><i class="fas fa-external-link-alt"></i><?php echo trans('messages.service_page'); ?></a></li>
</div>
<div class="col-md-7 col-xs-12">
<li><a href="<?php echo e(url('/')); ?>/works"><i class="fas fa-external-link-alt"></i><?php echo trans('messages.works_page'); ?></a></li>
<li><a href="<?php echo e(url('/')); ?>/news"><i class="fas fa-external-link-alt"></i><?php echo trans('messages.news_page'); ?></a></li>
<li><a href="<?php echo e(url('/')); ?>/contact"><i class="fas fa-external-link-alt"></i><?php echo trans('messages.contact_page'); ?></a></li>
</div>
</div>
</div>
   <div class="col-md-4  col-xs-12">
		<h4><?php echo trans('messages.contact_Information'); ?></h4>
			<div>
				<li><i class="fas fa-phone foot_contact"></i><?php echo e($sitesetting->phone); ?></li>
				<li><i class="fa fa-envelope foot_contact"></i><?php echo e($sitesetting->email); ?></li>
				<li><i class="fas fa-map-marker-alt foot_contact"></i>
                <?php if(app()->getLocale() == 'ar'): ?><?php echo e($sitesetting->address_ar); ?>

                <?php else: ?> <?php echo e($sitesetting->address_eng); ?>

                <?php endif; ?>
                </li>
			</div>
	</div>
</div>




					</div></div>
					<div class="coppy text-center">
							<div class="container">
								<h5 class="" style="font-size:13px;"><?php echo trans('messages.copy_right_foot'); ?>

                                <a href=""><?php echo trans('messages.copy_comp'); ?></a></h5>
								</div>
						</div>
				</footer>
  <script src="<?php echo e(url('/')); ?>/resources/them/js/bootstrap.min.js"></script>
  <script src="<?php echo e(url('/')); ?>/resources/them/js/main.js"></script>
    <script type="text/javascript" src="<?php echo e(url('/')); ?>/resources/them/toastr/toastr.min.js"></script>
    <link href="<?php echo e(url('/')); ?>/resources/them/toastr/toastr.min.css" rel="stylesheet">
<?php if(session()->has('msg')): ?>
<script>
$(document).ready(function(e) {
	toastr.info("<?php echo e(session()->get('msg')); ?>",  {timeOut: 5000})
});
</script>
<?php endif; ?>
<?php /**PATH /home/p2wisyst/public_html/gasc/resources/views/partials/footer.blade.php ENDPATH**/ ?>