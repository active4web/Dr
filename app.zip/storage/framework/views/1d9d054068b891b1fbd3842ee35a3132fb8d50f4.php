<html>
<head>
  <style>
      table,td{
          border:1px solid #ccc;
      }
      td{
          padding:6px;
      }
  </style>
</head>
<body>
<h3>Contact form</h3>
<table align="center" width="80%" border="0" cellspacing="0" cellpadding="0">
<tr>
  <td> Name : </td>
  <td> <?php echo e($phone); ?> </td>
</tr>

<tr>
  <td> phone : </td>
  <td> <?php echo e($phone); ?> </td>
</tr>


<tr>
  <td> Email : </td>
  <td> <?php echo e($email); ?> </td>
</tr>
<tr>
  <td> Massage : </td>
  <td> <?php echo e($msg); ?> </td>
</tr>
</table>
</body>
</html>
<?php /**PATH C:\wamp64\www\mywork\laravelv1\resources\views/pages/email.blade.php ENDPATH**/ ?>