<?php $__env->startSection('content'); ?>

				<div class="container main_breadcrumb">
					<div class="row">
						<div class="col-md-6 col-xs-5 col-sm-5 text-right">
							<div class="title">
								<h3><?php echo e(trans('messages.services')); ?></h3>
							</div>
						</div>
						<div class="col-md-6 col-xs-7 col-sm-7" >
							<ol class="breadcrumb text-left">
							  <li class=""><a href="<?php echo e(url('/')); ?>" class="home"><?php echo e(trans('messages.home_page')); ?></a></li>
							  <li class="active"><a href="#"><?php echo e(trans('messages.services')); ?></a></li>
							</ol>	
						</div>
					</div>
				</div>		
				<div class="clearfix"></div>
					</div>
		</div>						
       
        <div class="wrapper"  style="margin-top:30px;padding-bottom:3%">
   <div class="container">
<?php if(count($data)>0){
foreach($data as $prod) {
?>
      <div class="col-md-4  col-xs-12 col-sm-6 mb-n1 mainbox">
          <div class="row main-box">
               <div class="box4">
                  <div class="overlaybox"></div>
                      <img src="<?php echo e(url('/')); ?>/backend/uploads/services/<?php echo e($prod->img); ?>" class="rounded float-left img_business" alt="      <?php if(app()->getLocale() == 'ar'): ?><?php echo $prod->title_ar; ?>

               <?php else: ?><?php echo $prod->title_eng; ?><?php endif; ?>">
                         <div class="box-content">
                            <ul class="icon">
                               <li><a href="<?php echo e(url('/')); ?>/details/<?php echo e($prod->id); ?>" class="fas fa-external-link-alt"></a></li>
                            </ul>
                    </div>

                    </div>

            <div class="panel panel-default">
              <div class="panel-heading">      <?php if(app()->getLocale() == 'ar'): ?><?php echo $prod->title_ar; ?>

               <?php else: ?><?php echo $prod->title_eng; ?><?php endif; ?></div>
                    <p class="desc-services">
                    <?php if(app()->getLocale() == 'ar'): ?><?php echo $prod->description_ar; ?>

               <?php else: ?><?php echo $prod->description_en; ?><?php endif; ?>                
                    </p>
                </div>
             </div>
            </div>

            <?php }?>
            <div class="clearfix col-md-12"></div>
<div class="col-md-12 mb-n1 text-center"><?php echo e($data->onEachSide(2)->links()); ?></div>

<?php }else {?>
	<div class="col-md-12 mb-n1 ">لا يوجد محتوى حاليا</div>
<?php }?>

    </div>
            <div class="clearfix"></div>
        </div>


    <div class="clearfix"></div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout.insidemaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/p2wisyst/public_html/gasc/resources/views/pages/services.blade.php ENDPATH**/ ?>