<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.sub_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container main_breadcrumb">
				<div class="row">
					<div class="col-md-12"  style="text-align: center">
						<div class="title">
							<h3>فعاليات الشركة</h3>
						</div>
					</div>
					<div class="col-md-12" style="text-align: center">
						<ol class="breadcrumb text-center">
							<li><a href="index.html">الرئيسية</a></li>
							<li class="active"><a href="#">
                            فعاليات الشركة</a></li>
						</ol>
					</div>
				</div>
			</div>
            <div class="clearfix"></div>

					</div>
					</div>


                    <div class="wrapper"  style="margin-top:30px;padding-bottom:3%">


<div class="container">
<div class="row" style="margin:0px">
<div class="col-md-12" style="padding: 35px;">
<div class="row" style="margin:0px">

<?php
if(count($data)>0) {
foreach( $data as  $sundata){
?>

<div class="col-md-4  col-xs-12 col-sm-6 mb-n1 " style="padding-right:3px;padding-left:3px">
<div class="thumbnail thumbnail_events">
<img src="<?php echo e(url('/')); ?>/uploads/events/<?php echo e($sundata->img); ?>" class="rounded float-left img_business_events height_size">
</div>
<div class="caption_events">
<p class="title_events"><?php echo e($sundata->title); ?></p>
<p class="description_events"><?php echo e($sundata->description_ar); ?>

<a href="<?php echo e(url('')); ?>/event-details/<?php echo e($sundata->id); ?>" style="color:#226085; font-size:17px;font-weight:500;margin:0px 10px">المزيد</a>
<br>
<span><?php echo e($sundata->date); ?></span>
</p>
</div>
</div>

<?php }?>
<div class="col-md-12 mb-n1 "><?php echo e($data->onEachSide(2)->links()); ?></div>

<?php }else {?>
	<div class="col-md-12 mb-n1 ">لا يوجد محتوى حاليا</div>
<?php }?>


</div>
</div></div></div>
<div class="clearfix"></div>
<?php echo $__env->make("partials.clients", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="clearfix"></div>
<?php $__env->stopSection(); ?>
</div>



<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\mywork\laravelv1\resources\views/pages/events.blade.php ENDPATH**/ ?>