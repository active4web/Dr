<?php
foreach($sitesetting as $sitesetting)
?>
<footer>
				 <div class="overlay">
					<div class="container">
					<!-- Start Scroller -->
					<a href="#" class="scrollTop button" style="display: block;" id="elevator_item">
						<i class="fa fa-arrow-up" style="color:#fff;"></i></a>

					<!-- End Scroller -->
						<div class="row">
							<div class="col-md-3 col-xs-12">
								<h4>من نحن</h4>
								<p>
									هناك حقيقة مثبتة منذو زمن طويل وهى ان المحتوى المقروء لصفحة ماسينهى القارى عن التركيز على الشكل  الخارجى للنص او شكل توضع الفقرات فى الصفحة الى يقرأها ولذلك يتم استخدام طريقة
								<a  class="f-mor" href="">المزيد</a></p>
							</div>
							<div class="col-md-3  col-xs-12">

								<h4>الخدمات</h4>
									<div class="qanon">
										<div class="col-md-12">
											<li><a href=""><i class="fas fa-external-link-alt"></i>خدمات التقاضي والتحكيم</a></li>
											<li><a href=""><i class="fas fa-external-link-alt"></i>خدمات العقود والاتفتقات</a></li>
											<li><a href=""><i class="fas fa-external-link-alt"></i>خدمات االستشارات والدراسات</a></li>
											<li><a href=""><i class="fas fa-external-link-alt"></i>خدمات الشركات </a></li>
											<li><a href=""><i class="fas fa-external-link-alt"></i>خدمات المراجعة والتدقيق القانوني</a></li>
										</div>

									</div>
							</div>


							<div class="col-md-3  col-xs-12">

									<h4>اهم الروابط</h4>
										<div class="qanon">

											<div class="col-md-5 col-xs-12">
												<li><a href=""><i class="fas fa-external-link-alt"></i>الرئيسية</a></li>
												<li><a href=""><i class="fas fa-external-link-alt"></i>من نحن</a></li>
												<li><a href=""><i class="fas fa-external-link-alt"></i>خدماتنا</a></li>
												<li><a href=""><i class="fas fa-external-link-alt"></i>التوظيف</a></li>

											</div>
											<div class="col-md-7 col-xs-12">
													<li><a href=""><i class="fas fa-external-link-alt"></i>الاعمال</a></li>
													<li><a href="<?php echo e(url('/')); ?>clients"><i class="fas fa-external-link-alt"></i>العملاء</a></li>
													<li><a href=""><i class="fas fa-external-link-alt"></i> فعاليات المشركة</a></li>
													<li><a href=""><i class="fas fa-external-link-alt"></i>تواصل بنا</a></li>
												</div>
										</div>
								</div>

							<div class="col-md-3  col-xs-12">
								<h4>يسعدنا تواصلكم</h4>


								<div>
									<li><i class="fa fa-phone foot_contact"></i><?php echo e($sitesetting->email); ?></li>
									<li><i class="fa fa-envelope-open foot_contact"></i><?php echo e($sitesetting->phone); ?></li>
							</div>

								<div class="sochal pull-left" style="width:100%;text-align:right;">
									<a href="<?php echo e($sitesetting->whatsapp); ?>"><i class="fab fa-whatsapp fa-lg"></i></a>
									<a href="<?php echo e($sitesetting->twitter); ?>"><i class="fab fa-twitter fa-lg"></i></a>
									<a href="<?php echo e($sitesetting->facebook); ?>"><i class="fab fa-facebook-f fa-lg"></i></a>
								</div>

							</div>
						</div>

					<div class="coppy text-center">
						<div class="container">
							<h5 class="" style="font-size:13px;">©جميع الحقوق محفوظة   مدى 2019.تم التصميم بواسطة <a href="">WISYST</a></h5>


						</div>
					</div>
					</div>
                    			</div>
				</footer>


<script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
<script src="<?php echo e(url('/')); ?>/resources/them/js/bootstrap.min.js"></script>
<script src="<?php echo e(url('/')); ?>/resources/them/js/main.js"></script>
  <script src="<?php echo e(url('/')); ?>/resources/them/slick/slick.js" type="text/javascript" charset="utf-8"></script>
  <script type="text/javascript">
    $(document).on('ready', function() {


		$('.services').slick({
  slidesToShow: 3,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 2000,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
  ]
});

		$('.autoplay').slick({
  slidesToShow: 6,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 2000,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
  ]
});
    });
</script>
    <script type="text/javascript" src="<?php echo e(url('/')); ?>/resources/them/toastr/toastr.min.js"></script>
    <link href="<?php echo e(url('/')); ?>/resources/them/toastr/toastr.min.css" rel="stylesheet">
<?php if(session()->has('msg')): ?>
<script>
$(document).ready(function(e) {
	toastr.info("<?php echo e(session()->get('msg')); ?>",  {timeOut: 5000})
});
</script>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\mywork\gasc\frontend\resources\views/partials/footer.blade.php ENDPATH**/ ?>