<?php $__env->startSection('content'); ?>

<div class="container main_breadcrumb">
				<div class="row">
					<div class="col-md-12"  style="text-align: center">
						<div class="title">
							<h3>العملاء</h3>
						</div>
					</div>
					<div class="col-md-12" style="text-align: center">
						<ol class="breadcrumb text-center">
							<li><a href="index.html">الرئيسية</a></li>
							<li class="active"><a href="#">العملاء</a></li>
						</ol>
					</div>
				</div>
			</div>
            <div class="clearfix"></div>

					</div>
					</div>


				<div class="wrapper"  style="margin-top:30px;padding-bottom:3%">


						<div class="container">


											<div class="row">
								<div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center;margin-bottom:3%">
										<h3 class="servivce_title" >عملاء تشرفنا بخدمتهم
												<p class="bordbott" style="margin-left:auto;margin-right:auto"></p></h3>
										</div>
										<div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
												<div class="our-clints">
                                                <?php
                                                foreach($data as $result_data){
                                                ?>
													<div class="col-md-2 col-sm-4" style="margin-bottom:2%;">
							<a href="<?php echo e($result_data->link); ?>" target="_blank">
                            <img class="img-thumbnail" src="<?php echo e(url('')); ?>/uploads/clients/<?php echo e($result_data->img); ?>"  style="height:75px"></a>
													</div>

												<?php }?>

												</div>
                                                <?php echo e($data->onEachSide(2)->links()); ?>

                                            <!--   //<?php echo e($data->perPage()); ?>

                                              //  <?php echo e($data->nextPageUrl()); ?>

                                               // <?php echo e($data->currentPage()); ?>

                                                //<?php echo e($data->hasMorePages()); ?>

                                               // <?php echo e($data->lastItem()); ?>

                                              //  <?php echo e($data->firstItem()); ?>

                                               // <?php echo e($data->nextPageUrl()); ?>

                                               // <?php echo e($data->perPage()); ?>

                                                //<?php echo e($data->previousPageUrl()); ?>---->

											</div>
												</div>

						</div>
						<div class="clearfix"></div>
					</div>



				<div class="clearfix"></div>
<?php $__env->stopSection(); ?>
</div>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\mywork\laravelv1\resources\views/pages/clients.blade.php ENDPATH**/ ?>