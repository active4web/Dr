<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.sub_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container main_breadcrumb">
				<div class="row">
					<div class="col-md-12"  style="text-align: center">
						<div class="title">
							<h3>الأعمال</h3>
						</div>
					</div>
					<div class="col-md-12" style="text-align: center">
						<ol class="breadcrumb text-center">
							<li><a href="index.html">الرئيسية</a></li>
							<li class="active"><a href="#">
الأعمال</a></li>
						</ol>
					</div>
				</div>
			</div>
            <div class="clearfix"></div>

					</div>
					</div>


                    <div class="wrapper"  style="margin-top:30px;padding-bottom:3%">


<div class="container">
<div class="row" style="margin:0px">
<div class="col-md-12" style="padding: 35px;">
<div class="row" style="margin:0px">

<?php
if(count($data)>0) {
foreach( $data as  $sundata){
?>
<div class="col-md-4  col-xs-12 col-sm-6 mb-n1 " style="padding-right:3px;padding-left:3px">
		<div class="test" >
			<div class="box19 overlay">
			<img src="<?php echo e(url('')); ?>/uploads/works/<?php echo e($sundata->img); ?>" class="rounded float-left img_business">
			<div class="box-content">
				<div class="bord">
			<h3 class="title"><?php echo e($sundata->title); ?></h3>
			<ul class="icon">
			<li><a href="<?php echo e(url('')); ?>/details/<?php echo e($sundata->id); ?>" class="fa fa-eye"></a></li>
			</ul>
			</div>
			</div>
			</div>
	<a href="#" class="caption">
						<div class="caption">
							<p class="title_work"><?php echo e($sundata->title); ?></p>
								</div>
							</a>
		</div>
		</div>
<?php }?>
<div class="col-md-12 mb-n1 "><?php echo e($data->onEachSide(2)->links()); ?></div>

<?php }else {?>
	<div class="col-md-12 mb-n1 ">لا يوجد محتوى حاليا</div>
<?php }?>


</div>
</div></div></div>
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>
<?php $__env->stopSection(); ?>
</div>



<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\mywork\laravelv1\resources\views/pages/works.blade.php ENDPATH**/ ?>