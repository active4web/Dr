<?php $__env->startSection('content'); ?>

				<div class="container main_breadcrumb">
					<div class="row">
						<div class="col-md-6 col-xs-5 col-sm-5 text-right">
							<div class="title">
								<h3>
                <?php if(app()->getLocale() == 'ar'): ?><?php echo $data_main->title_ar; ?>

               <?php else: ?><?php echo $data_main->title_eng; ?>

               <?php endif; ?></h3>
							</div>
						</div>
						<div class="col-md-6 col-xs-7 col-sm-7" >
							<ol class="breadcrumb text-left">
							  <li class=""><a href="<?php echo e(url('/')); ?>" class="home"><?php echo e(trans('messages.home_page')); ?></a></li>
							  <li class="active"><a href="<?php echo e(url('/')); ?>/services"><?php echo e(trans('messages.services')); ?></a></li>
							</ol>
						</div>
					</div>
				</div>

				<div class="clearfix"></div>
					</div>
		</div>

<div class="wrapper"  style="margin-top:30px;padding-bottom:3%">
  <div class="container">
    <div class="row">
       <div class="col-md-5 col-sm-5 col-xs-12 hidden-xs img_work pic_news">
          <img alt="<?php if(app()->getLocale() == 'ar'): ?><?php echo $data_main->title_ar; ?> <?php else: ?><?php echo $data_main->title_eng; ?><?php endif; ?>" class="img-thumbnai" src="<?php echo e(config('global.DIR')); ?>/services/<?php echo e($data_main->img); ?>"   style="border-radius: 0.5em;">
       </div>
      <div class="col-md-5 col-sm-5 col-xs-12 hidden-md hidden-lg hidden-sm pic1 text-center img_work pic_news">
        <img alt="<?php if(app()->getLocale() == 'ar'): ?><?php echo $data_main->title_ar; ?> <?php else: ?><?php echo $data_main->title_eng; ?><?php endif; ?>" class="img-thumbnail" src="<?php echo e(config('global.DIR')); ?>/services/<?php echo e($data_main->img); ?>" style="border-radius: 0.5em;">
      </div>
      <div class="col-md-7 col-sm-7 col-xs-12 " >
        <h3 class="hed_about  news_title"  style="padding-top:30px"><?php if(app()->getLocale() == 'ar'): ?><?php echo $data_main->title_ar; ?> <?php else: ?><?php echo $data_main->title_eng; ?><?php endif; ?></h3>
           <div class="about_p"><?php if(app()->getLocale() == 'ar'): ?><?php echo $data_main->details_ar; ?> <?php else: ?><?php echo $data_main->details; ?><?php endif; ?>
            </div>

    </div>
</div>
</div>
<div class="clearfix"></div>
</div>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.insidemaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/p2wisyst/public_html/gasc/resources/views/pages/details.blade.php ENDPATH**/ ?>