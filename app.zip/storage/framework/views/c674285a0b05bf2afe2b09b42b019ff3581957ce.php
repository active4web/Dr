<?php $__env->startSection('content'); ?>

<div class="container main_breadcrumb">
					<div class="row">
						<div class="col-md-6 col-xs-5 col-sm-5 text-right">
							<div class="title">
								<h3><?php echo e(trans('messages.contact_page')); ?></h3>
							</div>
						</div>
						<div class="col-md-6 col-xs-7 col-sm-7" >
							<ol class="breadcrumb text-left">
							  <li class=""><a href="<?php echo e(url('/')); ?>" class="home"><?php echo e(trans('messages.home_page')); ?></a></li>
							  <li class="active"><a href="#"><?php echo e(trans('messages.contact_page')); ?></a></li>
							</ol>
						</div>
					</div>
				</div>
				<div class="clearfix"></div>
					</div>
		</div>


<div class="wrapper"  style="margin-top:30px;padding-bottom:3%">
<div class="container">
   <div class="row">
<div class="col-md-5 col-sm-5 col-xs-12 ">
   <div class="col-md-12">
	    <h3 class="servivce_title" > <?php echo e(trans("messages.Connect_now")); ?> <p class=""></p></h3>
        <p><?= trans("messages.we_communicate");?></p>
	</div>
<form class="col-md-12" action="#" id="myform" >
					<input type="hidden" name="mass_type" value="2">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="col-md-12">
            <input class="form-control input-lg" id="name" type="text" name="title" placeholder="<?= trans("messages.name_contact");?>">
        </div>
        <div class="col-md-12">
            <input class="form-control input-lg" id="phone" type="text" name="phone" placeholder="<?= trans("messages.phone_contact");?>">
        </div>
        <div class="col-md-12">
            <input class="form-control input-lg" id="email" type="text" name="email" placeholder="<?= trans("messages.mail_contact");?>">
        </div>
        <div class="col-md-12">
                <textarea class="form-control input-lg" id="message" name="msg" placeholder="<?= trans("messages.message_contact");?>"></textarea>
        </div>
        <div class="col-md-12">
        <button class="contact-btn send_txt" type="button"><?= trans("messages.established_Send");?></button>
        </div>

</form>
</div>
<div class="col-md-1 col-sm-1 col-xs-12 "></div>
<?php $__currentLoopData = $site_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siteinfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-md-6 col-sm-6 col-xs-12">
<div class="contact mt-50">
<?= $siteinfo->map?>
<div class="info">
    <li><div><?php echo e(trans("messages.contact_address")); ?>:</div><p>
    <?php if(app()->getLocale() == 'ar'): ?><?php echo $siteinfo->address_ar; ?>

    <?php else: ?><?php echo $siteinfo->address_eng; ?>

    <?php endif; ?>
                        </p> </li>
	<li><div><?php echo e(trans("messages.phone_contact")); ?>:</div><p><?= $siteinfo->phone?></p></li>
	<li><div><?php echo e(trans("messages.mail_contact")); ?>:</div><p><?= $siteinfo->email?></p></li>
</div>
</div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 </div>

						<div class="clearfix"></div>
					</div></div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.insidemaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/p2wisyst/public_html/gasc/resources/views/pages/contact.blade.php ENDPATH**/ ?>