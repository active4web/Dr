<?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
 if(Request::segment(1)=="works"){
?>
<link href="<?php echo e(url('/')); ?>/resources/them/css/lightbox.css" rel="stylesheet" type="text/css">
 <?php }?>
 <?php echo $__env->make('partials.minheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
 if(Request::segment(1)=="works"){
?>

<script src="<?php echo e(url('/')); ?>/resources/them/js/lightbox.js"></script>
<?php }?>
<?php
 if(Request::segment(1)=="contact"){
?>
 <?php echo $__env->make('partials.toastr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php }?>

<?php /**PATH /home/p2wisyst/public_html/gasc/resources/views/layout/insidemaster.blade.php ENDPATH**/ ?>