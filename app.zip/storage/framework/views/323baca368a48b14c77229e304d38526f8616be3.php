<?php $__env->startSection('content'); ?>



<?php
//print_r($data_main);
//echo $datamain->title;
?>

<div class="container main_breadcrumb">
				<div class="row">
					<div class="col-md-12"  style="text-align: center">
						<div class="title">
							<h3>تواصل معنا</h3>
						</div>
					</div>
					<div class="col-md-12" style="text-align: center;margin-top:10px;">
						<ol class="breadcrumb text-center">
							<li><a href="index.html">الرئيسية</a></li>
							<li class="active"><a href="#">تواصل معنا</a></li>
						</ol>
					</div>
                </div>
            </div>
            <div class="clearfix"></div>

</div>
</div></div>
<?php
foreach($data as $data)
?>

<div class="wrapper" style="margin-top:30px;padding-bottom:3%">
<div class="container">

<div class="row">



								<div class="col-md-6 col-sm-6 col-xs-12 ">
										<div class="contact">
										<h3 class="servivce_title">يسعدنا تواصلكم<p class="bordbott"></p></h3>
										<div class="info">

										<li><div><i class="fas fa-map-marker-alt fa-lg"></i></div><p><?php echo e($data->address); ?></p> </li>
										<li><div><i class="fa fa-phone phone fa-lg"></i></div><p><?php echo e($data->phone); ?></p></li>
										<li><div><i class="fas fa-envelope fa-lg"></i></div><p><?php echo e($data->email); ?></p></li>

										</div>
									</div>
									</div>

							<div class="col-md-6 col-sm-6 col-xs-12 ">
								<div class="col-md-12">
										<h3 class="servivce_title" style="padding-right: 20px;">تواصل معانا الان<p class="bordbott"></p></h3>

								</div>



			<form class="col-md-12" action="<?php echo e(url('contact')); ?>" id="myform" method="post">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="mass_type" value="2">
							<div class="col-md-12">
								<input class="form-control input-lg" id="name" name="title" type="text" placeholder="الاسم">
                            </div>
                            <div class="col-md-12">
									<input class="form-control input-lg" id="email" name="email" type="text" placeholder="البريد الألكترونى">
							</div>
							<div class="col-md-12">
									<input class="form-control input-lg" id="phone" name="phone" type="text" placeholder="رقم الجوال">
							</div>
							<div class="col-md-12">
								<textarea class="form-control input-lg" id="message" name="msg" placeholder="الرسالة"></textarea>
							</div>
							<div class="col-md-12">
									<button class="contact-btn" type="submit">أرسل الآن</button>
								</div>


						</form>


						</div>

                    </div>

<!-- AddToAny END -->
		</div>



        <?php echo $__env->make("partials.clients", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
<!---------------------------6Row-------------------------------->
</div>
<div class="clearfix"></div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\mywork\laravelv1\resources\views/pages/contact.blade.php ENDPATH**/ ?>