<?php $__env->startSection('content'); ?>
    <!-- Preloader Begin -->
    <?php
foreach($sitesetting as $sitesetting)
foreach($site_info as $site_data)
foreach($home_page as $homepage)
?>

<style>
.slide{
	position: relative !important;
	z-index: 0 !important;
}
.text{color: #fff;
    bottom: 20px;
    z-index: 9999999999999;
    position: absolute;
    right: 20px;
	font-size:18px;
	line-height: 30px;

}
.slider_overlay{
	background-color:rgba(25, 24, 24, 0.6);
    padding-bottom: 0%;
    padding-top: 6px;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    position: absolute;
}
</style>

<div class="header-slider"  style="direction: ltr">
<?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<figure  style="position: relative;">
								<img src="<?php echo e(url('/')); ?>/backend/uploads/slider/<?php echo e($slid->img); ?>" alt="">
                                <div class="slider_overlay"></div>

								<figcaption class="card-body">
<?php if(app()->getLocale() == 'ar'): ?>
    <?php echo $slid->title; ?>

<?php else: ?>
    <?php echo $slid->title_en; ?>

<?php endif; ?>;
									</figcaption>
							</figure>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>

			<div class="wrapper"  style="margin-top:30px;padding-bottom:1%">
				<div class="container">
					<div class="row">
							<div class="col-md-5 col-sm-5 col-xs-12">
									<div class="pic" style="margin-top:0px;">
											<img class="img-responsive " src="<?php echo e(url('/')); ?>/backend/uploads/site_setting/<?php echo e($homepage->slider_background); ?>" style="border-radius: 0.4em;">
											</div>
							</div>
							<div class="col-md-7 col-sm-7 col-xs-12">
									<ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
											<li class="nav-item active abou">
											  <a class="nav-link active" id="pills-about-tab" data-toggle="pill" href="#pills-about" role="tab" aria-controls="pills-about" aria-selected="true">
													<span style="display: block"><img src="<?php echo e(url('/')); ?>/backend/uploads/site_setting/about_active.jpg"  class="tab-img img-tab-about"></span>
													<span style="display: block"><?php echo e(@trans('messages.about')); ?></span>

											  </a>
											</li>
											<li class="nav-item vis">
											  <a class="nav-link" id="pills-vision-tab" data-toggle="pill" href="#pills-vision" role="tab" aria-controls="pills-vision" aria-selected="false">
													<span style="display: block"><img  src="<?php echo e(url('/')); ?>/backend/uploads/site_setting/vision_no_active.png" class="tab-img img-tab-vision"></span>
                                                    <?php echo e(@trans('messages.vision')); ?></a>
											</li>
											<li class="nav-item mess">
											  <a class="nav-link" id="pills-message-tab" data-toggle="pill" href="#pills-message" role="tab" aria-controls="pills-message" aria-selected="false">
													<span style="display: block"><img src="<?php echo e(url('/')); ?>/backend/uploads/site_setting/mission_no_active.png"  class="tab-img img-tab-message"></span>
                                                    <?php echo e(@trans('messages.message')); ?></a>
											</li>
											<li class="nav-item goal">
													<a class="nav-link" id="pills-goals-tab" data-toggle="pill" href="#pills-goals" role="tab" aria-controls="pills-goals" aria-selected="false">
															<span style="display: block"><img  class="tab-img img-tab-goals" src="<?php echo e(url('/')); ?>/backend/uploads/site_setting/goals_no_active.png"></span>
                                                            <?php echo e(@trans('messages.goals')); ?></a>
												  </li>
										  </ul>
<div class="tab-content" id="pills-tabContent">
<div class="tab-pane fade  active in" id="pills-about" role="tabpanel" aria-labelledby="pills-about-tab">

<div class="row">

<div class="col-md-12"><p class="p">
<?php if(app()->getLocale() == 'ar'): ?>
    <?php echo $homepage->home_about; ?>

<?php else: ?>
    <?php echo $homepage->home_about_en; ?>

<?php endif; ?>;

</p></div>

</div>

		</div>

<div class="tab-pane fade" id="pills-vision" role="tabpanel" aria-labelledby="pills-vision-tab">

		<div class="row">

				<div class="col-md-12"><p class="p">
<?php if(app()->getLocale() == 'ar'): ?>
    <?php echo $homepage->home_vision; ?>

<?php else: ?>
    <?php echo $homepage->home_vision_en; ?>

<?php endif; ?>;
				</p></div>

				</div>
</div>
<div class="tab-pane fade" id="pills-message" role="tabpanel" aria-labelledby="pills-message-tab">
		<div class="row">

				<div class="col-md-12"><p class="p">
<?php if(app()->getLocale() == 'ar'): ?>
    <?php echo $homepage->home_mission; ?>

<?php else: ?>
    <?php echo $homepage->home_mission_en; ?>

<?php endif; ?>;
				</p></div>

				</div>
</div>
<div class="tab-pane fade" id="pills-goals" role="tabpanel" aria-labelledby="pills-goals-tab">
		<div class="row">
<div class="col-md-12"><p class="p">
<?php if(app()->getLocale() == 'ar'): ?>
    <?php echo $homepage->home_goals; ?>

<?php else: ?>
    <?php echo $homepage->home_goals_en; ?>

<?php endif; ?>;
                </p></div>
        </div>

</div>
</div>
</div>

</div></div>
<div class="clearfix"></div>
			</div>

		<!-------------------------------------------------------------------------------------->

<div class="wrapper"  style="margin-top:0px;padding-bottom:1%">
	<div class="container" style="direction: ltr">
			<div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
			  <h3 class="hed_about" > <h1><?php echo e(trans('messages.services')); ?>


</h1> <p class="bordbott" style="margin-left:auto;margin-right:auto"></p></h3>
			</div>
		<div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">

<div class="owl-carousel owl-theme" id="owl-demo">

<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $services): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="item item-home">
				<div class="box_4">
					<div class="thumbnail thumbnail_events">
								<div class="overlaybox"></div>
						<img src="<?php echo e(url('/')); ?>/backend/uploads/services/<?php echo e($services->img); ?>" class="rounded float-left img_business_events" alt=" <?php if(app()->getLocale() == 'en'): ?>:<?php echo $services->title_ar; ?>

               <?php else: ?>: <?php echo $services->title_eng; ?><?php endif; ?>;">
							<div class="box-content">
								<ul class="icon">
									<li><a href="<?php echo e(url('/')); ?>/details/<?php echo $services->id; ?>" class="fas fa-external-link-alt"></a></li>
								</ul>
							</div>
					</div>
				</div>
		<div class="caption_events">
			<a href="#" class="hp_link">
			  <p class="title_events_home">
              <?php if(app()->getLocale() == 'ar'): ?><?php echo $services->title_ar; ?>

               <?php else: ?><?php echo $services->title_eng; ?><?php endif; ?>
              </p>
			    <p class="description_events mm1">
                <?php if(app()->getLocale() == 'ar'): ?><?php echo $services->description_ar; ?>

               <?php else: ?><?php echo $services->description_en; ?><?php endif; ?>

			    </p>
			</a>
        </div>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


			  </div>

		</div>
    </div>
</div>
<!----معرض الاعمال-->
<div class="wrapper"  style="margin-top:0px;padding-bottom:1%">
	<div class="container" style="direction: ltr">
		<div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
			<h3 class="hed_about" ><?php echo e(trans('messages.works')); ?><p class="bordbott" style="margin-left:auto;margin-right:auto"></p></h3>
		</div>
		<div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">

				<div id="owl-demo-1" class="owl-carousel">

                <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $works): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="item item-gallery">
								<div class="box_5">
									<div class="thumbnail thumbnail_events">
												<div class="overlayboxgallery"></div>
										<img src="<?php echo e(url('/')); ?>/backend/uploads/clients/<?php echo e($works->img); ?>" class="galleryimg">
											<div class="box-content">
												<ul class="icon">
													<li><a href="<?php echo e(url('/')); ?>/works" class="fas fa-eye"></a></li>
												</ul>
											</div>
									</div>
								</div>

					</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


				</div>

		</div>

	</div>
</div>

<!---###########-->

<!----احدث الاخبار -->
<div class="wrapper"  style="margin-top:0px;padding-bottom:3%">
	<div class="container" style="direction: ltr">
		<div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
			<h3 class="hed_about" ><?php echo e(trans('messages.latest-news')); ?><p class="bordbott" style="margin-left:auto;margin-right:auto"></p></h3>
			</div>

			<div class="col-md-12 col-sm-12 col-xs-12 " style="text-align:center">
<div id="owl-demo-2" class="owl-carousel">
<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="item newshome">
								<div class="col-md-12 mb-n1 btr" style="padding-right:0px;padding-left:0px">
										<a href="<?php echo e(url('/')); ?>/news-details/<?php echo $news->id; ?>" class="hp_link">
										<div class="thumbnail thumbnail_events">
											<img src="<?php echo e(url('/')); ?>/backend/uploads/events/<?php echo e($news->img); ?>" class="rounded float-left img_business_events">
											<span class="date">
                <?php if(app()->getLocale() == 'ar'): ?><?php echo $news->special_date; ?>

               <?php else: ?><?php echo $news->special_date_en; ?><?php endif; ?></span>
										</div>
									</a><div class="caption_events"><a href="#" class="hp_link">
											<p class="title_events">
               <?php if(app()->getLocale() == 'ar'): ?><?php echo $news->title; ?>

               <?php else: ?><?php echo $news->title_en; ?><?php endif; ?></p>
											<p class="description_events">
            <?php if(app()->getLocale() == 'ar'): ?><?php echo $news->description_ar; ?>

               <?php else: ?><?php echo $news->description_en; ?><?php endif; ?>
											</p>
											</a><p class="p-news"><a href="<?php echo e(url('/')); ?>/news-details/<?php echo $news->id; ?>" class="news-link"><?php echo e(trans('messages.read_more')); ?></a></p>
												</div>
									</div>
						</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



					</div>

			</div>
		</div>
	</div>

<!---###########-->


				</div>

<div class="clearfix"></div>

<?php $__env->stopSection(); ?>
</div></div>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/p2wisyst/public_html/gasc/resources/views/pages/home.blade.php ENDPATH**/ ?>