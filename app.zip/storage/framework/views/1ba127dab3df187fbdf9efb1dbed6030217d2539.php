

<?php
foreach($site_info as $sitesetting)
?>
 	<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="keywords" content="<?php echo e($sitesetting->keywords); ?>">
		<meta name="description" content="<?php echo e($sitesetting->description); ?>">
		<title>
        <?php if(app()->getLocale() == 'ar'): ?> <?php echo e($sitesetting->name_site_ar); ?> <?php else: ?> <?php echo e($sitesetting->name_site); ?> <?php endif; ?>
		</title>
  <meta charset="UTF-8">

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.11.1/css/all.css">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


  <?php if(app()->getLocale() == 'ar'): ?>
  <link href="<?php echo e(url('/')); ?>/resources/them/css/bootstrap.css" rel="stylesheet" type="text/css">
  <?php else: ?>
    <link href="<?php echo e(url('/')); ?>/resources/them/css/bootstrap-en.css" rel="stylesheet" type="text/css">
<?php endif; ?>

  <link href="<?php echo e(url('/')); ?>/resources/them/css/style.css" rel="stylesheet" type="text/css">
  <?php if(app()->getLocale() == 'en'): ?>
    <link href="<?php echo e(url('/')); ?>/resources/them/css/style-en.css" rel="stylesheet" type="text/css">
<?php endif; ?>
  <link href="<?php echo e(url('/')); ?>/resources/them/css/customs.css" rel="stylesheet" type="text/css">
  <link href="<?php echo e(url('/')); ?>/resources/them/css/main.css" rel="stylesheet" type="text/css">
  <link href="<?php echo e(url('/')); ?>/resources/them/css/effects.min.css" rel="stylesheet" type="text/css">
  <style>
		@import  url(http://fonts.googleapis.com/earlyaccess/notosanskufiarabic.css);
		</style>
	<link rel="shortcut icon" href="<?php echo e(url('/')); ?>/backend/uploads/site_setting/<?php echo e($sitesetting->favicon); ?>" type="image/x-icon" />

<?php /**PATH C:\wamp64\www\mywork\gasc\resources\views/partials/head.blade.php ENDPATH**/ ?>