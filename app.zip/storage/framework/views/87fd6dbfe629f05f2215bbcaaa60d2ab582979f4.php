<?php $__env->startSection('content'); ?>

<div class="container main_breadcrumb">
					<div class="row">
						<div class="col-md-6 col-xs-5 col-sm-5 text-right">
							<div class="title">
								<h3><?php echo e(trans('messages.news_page')); ?></h3>
							</div>
						</div>
						<div class="col-md-6 col-xs-7 col-sm-7" >
							<ol class="breadcrumb text-left">
							  <li class=""><a href="<?php echo e(url('/')); ?>" class="home"><?php echo e(trans('messages.home_page')); ?></a></li>
							  <li class="active"><a href="#"><?php echo e(trans('messages.news_page')); ?></a></li>
							</ol>
						</div>
					</div>
				</div>
				<div class="clearfix"></div>
					</div>
		</div>


        <div class="wrapper"  style="margin-top:30px;padding-bottom:3%">
    <div class="container">
      <div class="row" style="margin:0px">
         <div class="col-md-12" style="padding: 35px;">
            <div class="row" style="margin:0px">
<?php if(count($data)>0): ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	           <div class="col-md-4  col-xs-12 col-sm-6 mb-n1 btr" style="padding-right:5px;padding-left:5px">
		        <a href="<?php echo e(url('/')); ?>/news-details/<?php echo e($prod->id); ?>" class="hp_link">
			        <div class="thumbnail thumbnail_events">
				       <img src="<?php echo e(config('global.DIR')); ?>/events/<?php echo e($prod->img); ?>" class="rounded float-left img_business_events" alt=" <?php if(app()->getLocale() == 'ar'): ?><?php echo $prod->title; ?><?php else: ?><?php echo $prod->title_en; ?> <?php endif; ?>">
					      <span class="date">
                            <?php if(app()->getLocale() == 'ar'): ?><?php echo $prod->special_date; ?>

                        <?php else: ?><?php echo $prod->special_date_en; ?>

                        <?php endif; ?>
                         </span>
			        </div>
	            <div class="caption_events">
                    <p class="title_events">
                    <?php if(app()->getLocale() == 'ar'): ?><?php echo $prod->title; ?>

                        <?php else: ?><?php echo $prod->title_en; ?>

                    <?php endif; ?>
                     </p>
			          <p class="description_events">
                      <?php if(app()->getLocale() == 'ar'): ?><?php echo mb_substr($prod->description_ar,0,120); ?>

                        <?php else: ?><?php echo mb_substr($prod->description_en,0,120); ?>

                    <?php endif; ?>

			          </p>
		             <p class="p-news"><a href="<?php echo e(url('/')); ?>/news-details/<?php echo e($prod->id); ?>"  class="news-link"><?php echo e(trans('messages.read_more')); ?></a></p>
	            </div>
	        	</a>
	          </div>

     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="clearfix col-md-12"></div>
 <div class="col-md-12" style="text-align:center;min-height:40px"><?php echo e($data->onEachSide(2)->links()); ?></div>
<?php else: ?>
<div class="col-md-12" style="text-align:center"><?= lang("no_data");?></div>
<?php endif; ?>

			</div>
          </div>
       </div>
    </div>
<div class="clearfix"></div>
		</div>

<div class="clearfix"></div>
<?php $__env->stopSection(); ?>
</div>



<?php echo $__env->make('layout.insidemaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gascaluc/public_html/resources/views/pages/news.blade.php ENDPATH**/ ?>