<?php
   
   return [
       'pagination_records'=>10,
    'DIR'=>url('/')."/"."backend/uploads/",
    ]

?>