<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SliderModel extends Model
{
    //
    protected $table =  'sliders';
	protected $primaryKey = 'id';
}
